'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

export default function SignupPage() {
  const router = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, fullName })
      })
      const data = await res.json()
      if (data.success) {
        router.push('/auth/login?message=Check your email to verify')
      } else {
        setError(data.error || 'Signup failed')
      }
    } catch (err) {
      setError('Error signing up')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black to-gray-900 flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-white rounded-lg shadow-xl p-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-black mb-2">LooKit</h1>
          <p className="text-gray-600">Join Nigeria's fashion marketplace</p>
        </div>
        {error && <div className="mb-4 p-4 bg-red-100 text-red-700 rounded text-sm">{error}</div>}
        <form onSubmit={handleSignup} className="space-y-4">
          <input type="text" placeholder="Full Name" value={fullName} onChange={(e) => setFullName(e.target.value)} required className="input-primary" />
          <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required className="input-primary" />
          <input type="password" placeholder="Password (min 8 chars)" value={password} onChange={(e) => setPassword(e.target.value)} required className="input-primary" />
          <button type="submit" disabled={loading} className="btn-primary w-full">{loading ? 'Creating...' : 'Sign Up'}</button>
        </form>
        <p className="text-center text-gray-600 mt-6 text-sm">Already have an account? <Link href="/auth/login" className="text-black font-semibold">Log in</Link></p>
      </div>
    </div>
  )
}
