'use client'
import { useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import Link from 'next/link'

export default function LoginPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const message = searchParams.get('message')
  const [email, setEmail] = useState('demo@lookit.local')
  const [password, setPassword] = useState('Test@1234')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      })
      const data = await res.json()
      if (data.success) {
        localStorage.setItem('accessToken', data.session.access_token)
        localStorage.setItem('userId', data.user.id)
        router.push('/explore')
      } else {
        setError(data.error || 'Login failed')
      }
    } catch (err) {
      setError('Error logging in')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black to-gray-900 flex items-center justify-center px-4">
      <div className="w-full max-w-md bg-white rounded-lg shadow-xl p-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-black mb-2">LooKit</h1>
          <p className="text-gray-600">Welcome back</p>
        </div>
        {message && <div className="mb-4 p-4 bg-green-100 text-green-700 rounded text-sm">{message}</div>}
        {error && <div className="mb-4 p-4 bg-red-100 text-red-700 rounded text-sm">{error}</div>}
        <form onSubmit={handleLogin} className="space-y-4">
          <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required className="input-primary" />
          <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required className="input-primary" />
          <button type="submit" disabled={loading} className="btn-primary w-full">{loading ? 'Logging in...' : 'Log In'}</button>
        </form>
        <p className="text-center text-gray-600 mt-6 text-sm">Don't have an account? <Link href="/auth/signup" className="text-black font-semibold">Sign up</Link></p>
        <p className="text-center text-xs text-gray-500 mt-4">Demo: demo@lookit.local / Test@1234</p>
      </div>
    </div>
  )
}
