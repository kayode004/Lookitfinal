'use client'
import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { ChevronLeft, ShoppingCart } from 'lucide-react'

export default function ListingPage() {
  const params = useParams()
  const router = useRouter()
  const [listing, setListing] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [adding, setAdding] = useState(false)

  useEffect(() => {
    fetchListing()
  }, [params.id])

  const fetchListing = async () => {
    try {
      const res = await fetch(`/api/listings/${params.id}`)
      const data = await res.json()
      setListing(data)
    } catch (err) {
      console.error('Error:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleAddToCart = async () => {
    setAdding(true)
    try {
      await fetch('/api/cart', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          listing_id: params.id,
          quantity: 1
        })
      })
      router.push('/cart')
    } catch (err) {
      alert('Error adding to cart')
    } finally {
      setAdding(false)
    }
  }

  const formatPrice = (kobo?: number) => kobo ? `₦${(kobo / 100000).toLocaleString()}` : '—'

  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>
  if (!listing) return <div className="flex items-center justify-center h-screen">Not found</div>

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b">
        <div className="container-responsive py-4">
          <button onClick={() => router.back()} className="flex items-center gap-2">
            <ChevronLeft size={20} />
            Back
          </button>
        </div>
      </header>

      <main className="container-responsive py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="bg-gray-200 aspect-square rounded-lg flex items-center justify-center text-gray-400">
            No image
          </div>

          <div>
            <h1 className="text-3xl font-bold mb-2">{listing.title}</h1>
            <p className="text-gray-600 mb-4">{listing.description}</p>
            
            <div className="bg-gray-100 p-4 rounded-lg mb-6">
              <p className="text-2xl font-bold text-black">{formatPrice(listing.rental_price_kobo)}</p>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <p className="text-gray-600 text-sm">Category</p>
                <p className="font-semibold capitalize">{listing.category || '—'}</p>
              </div>
              <div>
                <p className="text-gray-600 text-sm">Condition</p>
                <p className="font-semibold capitalize">{listing.condition}</p>
              </div>
              <div>
                <p className="text-gray-600 text-sm">Size</p>
                <p className="font-semibold capitalize">{listing.size || '—'}</p>
              </div>
              <div>
                <p className="text-gray-600 text-sm">Brand</p>
                <p className="font-semibold capitalize">{listing.brand || '—'}</p>
              </div>
            </div>

            <button 
              onClick={handleAddToCart}
              disabled={adding}
              className="btn-primary w-full flex items-center justify-center gap-2"
            >
              <ShoppingCart size={20} />
              {adding ? 'Adding...' : 'Add to Cart'}
            </button>
          </div>
        </div>
      </main>
    </div>
  )
}
