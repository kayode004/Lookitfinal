'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Search, ShoppingCart } from 'lucide-react'

export default function ExplorePage() {
  const [listings, setListings] = useState<any[]>([])
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchListings()
  }, [search, category])

  const fetchListings = async () => {
    try {
      const params = new URLSearchParams()
      if (search) params.append('search', search)
      if (category) params.append('category', category)
      
      const res = await fetch(`/api/listings?${params}`)
      const data = await res.json()
      setListings(data.listings || [])
    } catch (err) {
      console.error('Error:', err)
    } finally {
      setLoading(false)
    }
  }

  const formatPrice = (kobo?: number) => {
    if (!kobo) return '—'
    return `₦${(kobo / 100000).toLocaleString()}`
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="container-responsive py-4">
          <div className="flex items-center justify-between mb-4">
            <Link href="/" className="text-2xl font-bold">LooKit</Link>
            <Link href="/cart" className="flex items-center gap-2 bg-black text-white px-4 py-2 rounded-lg">
              <ShoppingCart size={20} />
              Cart
            </Link>
          </div>
          
          <div className="flex gap-4 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
              <input
                type="text"
                placeholder="Search fashion items..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="input-primary pl-10"
              />
            </div>
          </div>

          <div className="flex gap-2 overflow-x-auto pb-2">
            {['clothing', 'footwear', 'accessories', 'bags'].map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(category === cat ? '' : cat)}
                className={`px-4 py-2 rounded-lg whitespace-nowrap capitalize ${
                  category === cat
                    ? 'bg-black text-white'
                    : 'bg-white border border-gray-300'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main className="container-responsive py-8">
        {loading ? (
          <p className="text-center text-gray-500">Loading...</p>
        ) : listings.length === 0 ? (
          <p className="text-center text-gray-500">No items found</p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {listings.map((item) => (
              <Link key={item.id} href={`/listings/${item.id}`} className="group">
                <div className="bg-white rounded-lg shadow hover:shadow-lg transition overflow-hidden">
                  <div className="aspect-square bg-gray-200 flex items-center justify-center text-gray-400">
                    No image
                  </div>
                  <div className="p-4">
                    <p className="text-xs text-gray-500 mb-1 capitalize">{item.condition}</p>
                    <h3 className="font-semibold line-clamp-2 mb-2">{item.title}</h3>
                    <p className="text-sm font-bold text-black mb-1">
                      {formatPrice(item.rental_price_kobo)}
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
